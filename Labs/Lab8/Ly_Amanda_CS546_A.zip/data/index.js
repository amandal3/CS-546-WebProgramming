module.exports = {
    people: require("./people")
};