const animalData = require("./animals");
const postData = require("./posts");

module.exports = {
    animals: animalData,
    posts: postData
};